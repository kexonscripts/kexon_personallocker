
local ESX = exports.es_extended:getSharedObject()
local registeredStashes = {}

-- Discord Webhook Log Function
local function sendDiscordLog(title, description, color)
    if not Config.DiscordWebhook or Config.DiscordWebhook == '' or Config.DiscordWebhook == 'YOUR_WEBHOOK_URL_HERE' then return end
    local embed = {
        title = title,
        description = description,
        color = color,
        footer = { text = os.date('%Y-%m-%d %H:%M:%S') }
    }
    local payload = {
        username = Config.WebhookName or 'Kexon Personal Locker',
        embeds = { embed }
    }
    if Config.WebhookImage and Config.WebhookImage ~= '' then
        payload.avatar_url = Config.WebhookImage
    end
    PerformHttpRequest(Config.DiscordWebhook, function(err, text, headers)
        if err ~= 200 and err ~= 204 then
            print('[kexon_personallocker] Discord webhook error: ' .. tostring(err))
        end
    end, 'POST', json.encode(payload), { ['Content-Type'] = 'application/json' })
end

CreateThread(function()
    while not exports.oxmysql do
        Wait(100)
    end

    exports.oxmysql:execute([[
        CREATE TABLE IF NOT EXISTS kexon_personallocker (
            identifier VARCHAR(64) PRIMARY KEY,
            slots INT NOT NULL,
            weight INT NOT NULL
        )
    ]])
end)

local function getCharIdentifier(src)
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return nil end
    return xPlayer.identifier
end

local function getPlayerName(src)
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return 'Unknown' end
    return xPlayer.getName()
end

local function loadLocker(identifier)
    local result = exports.oxmysql:executeSync(
        'SELECT slots, weight FROM kexon_personallocker WHERE identifier = ?',
        { identifier }
    )

    if not result or not result[1] then
        exports.oxmysql:executeSync(
            'INSERT INTO kexon_personallocker (identifier, slots, weight) VALUES (?, ?, ?)',
            { identifier, Config.BaseSlots, Config.BaseWeight }
        )
        return { slots = Config.BaseSlots, weight = Config.BaseWeight }
    end

    return result[1]
end

RegisterNetEvent('kexon_locker:open', function()
    local src = source
    local identifier = getCharIdentifier(src)
    if not identifier then return end

    local locker = loadLocker(identifier)
    local stashId = 'personal_locker_' .. identifier

    if not registeredStashes[stashId] then
        exports.ox_inventory:RegisterStash(
            stashId,
            'Personal Locker',
            locker.slots,
            locker.weight,
            identifier
        )
        registeredStashes[stashId] = true
    end

    -- Log: Locker opened
    sendDiscordLog(
        'Locker Opened',
        string.format('**Player:** %s\n**Identifier:** %s\n**Slots:** %s | **Weight:** %s',
            getPlayerName(src), identifier, locker.slots, locker.weight),
        3447003
    )

    TriggerClientEvent('ox_inventory:openInventory', src, 'stash', stashId)
end)

RegisterNetEvent('kexon_locker:upgrade', function(kind, amount)
    local src = source
    local identifier = getCharIdentifier(src)
    if not identifier then return end

    amount = tonumber(amount) or 1
    if amount < 1 then amount = 1 end

    local locker = loadLocker(identifier)
    local price, add, maxVal, currentVal, label

    if kind == 'slots' then
        currentVal = locker.slots
        maxVal = Config.MaxSlots
        add = Config.Upgrade.slots.add * amount
        label = 'Slots'
        if currentVal >= maxVal then
            TriggerClientEvent('ox_lib:notify', src, { description='Slots already maxed', type='error' })
            return
        end
        price = Config.Upgrade.slots.price * amount
        locker.slots = math.min(currentVal + add, maxVal)
    elseif kind == 'weight' then
        currentVal = locker.weight
        maxVal = Config.MaxWeight
        add = Config.Upgrade.weight.add * amount
        label = 'Weight'
        if currentVal >= maxVal then
            TriggerClientEvent('ox_lib:notify', src, { description='Weight already maxed', type='error' })
            return
        end
        price = Config.Upgrade.weight.price * amount
        locker.weight = math.min(currentVal + add, maxVal)
    else
        return
    end

    if exports.ox_inventory:GetItemCount(src, 'money') < price then
        TriggerClientEvent('ox_lib:notify', src, { description='Not enough money ($' .. price .. ')', type='error' })
        return
    end

    exports.ox_inventory:RemoveItem(src, 'money', price)

    exports.oxmysql:executeSync(
        'UPDATE kexon_personallocker SET slots = ?, weight = ? WHERE identifier = ?',
        { locker.slots, locker.weight, identifier }
    )

    registeredStashes['personal_locker_' .. identifier] = nil

    TriggerClientEvent('ox_lib:notify', src, {
        description = string.format('Locker upgraded: +%s %s (x%s)', add, label, amount),
        type = 'success'
    })

    -- Log: Locker upgraded
    sendDiscordLog(
        '⬆️ Locker Upgraded',
        string.format('**Player:** %s\n**Identifier:** %s\n**Upgrade:** +%s %s (x%s)\n**Cost:** $%s\n**New %s:** %s',
            getPlayerName(src), identifier, add, label, amount, price, label,
            kind == 'slots' and locker.slots or locker.weight),
        3066993
    )
end)

-- Hook into ox_inventory to log items moving in/out of personal lockers
CreateThread(function()
    while not exports.ox_inventory do
        Wait(500)
    end
    Wait(2000)

    local ok, hookId = pcall(function()
        return exports.ox_inventory:registerHook('swapItems', function(payload)
            return true -- allow the action, we just want to track it
        end, {
            inventoryFilter = { '^personal_locker_' }
        })
    end)

    if not ok or not hookId then
        print('[kexon_personallocker] WARNING: Failed to register swapItems hook')
        return
    end

    print('[kexon_personallocker] Swap hook registered (id: ' .. tostring(hookId) .. ')')

    -- Post-hook: fires after the swap actually completes
    AddEventHandler(hookId, function(success, payload)
        if not success then return end
        if not payload then return end

        local src = payload.source
        local xPlayer = ESX.GetPlayerFromId(src)
        if not xPlayer then return end

        local playerName = xPlayer.getName()
        local identifier = xPlayer.identifier

        -- Get inventory IDs as strings
        local fromInv = payload.fromInventory
        local toInv = payload.toInventory
        local fromInvStr = type(fromInv) == 'table' and (fromInv.id or '') or tostring(fromInv or '')
        local toInvStr = type(toInv) == 'table' and (toInv.id or '') or tostring(toInv or '')

        -- Get item info from the slot data
        local slot = payload.fromSlot
        local itemName = slot and (slot.name or 'unknown') or 'unknown'
        local count = payload.count or (slot and slot.count) or 1

        if toInvStr:find('personal_locker_') then
            -- Item going INTO locker
            sendDiscordLog(
                'Item Deposited',
                string.format('**Player:** %s\n**Identifier:** %s\n**Item:** %s x%s',
                    playerName, identifier, itemName, count),
                3066993
            )
        elseif fromInvStr:find('personal_locker_') then
            -- Item coming OUT of locker
            sendDiscordLog(
                'Item Withdrawn',
                string.format('**Player:** %s\n**Identifier:** %s\n**Item:** %s x%s',
                    playerName, identifier, itemName, count),
                15105570
            )
        end
    end)

    print('[kexon_personallocker] Item deposit/withdraw logging active')
end)
