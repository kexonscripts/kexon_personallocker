CREATE TABLE `kexon_personallocker` (
  `id` int(11) NOT NULL,
  `identifier` varchar(64) NOT NULL,
  `slots` int(11) NOT NULL DEFAULT 50,
  `weight` int(11) NOT NULL DEFAULT 100000,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `kexon_personallocker`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `identifier_unique` (`identifier`);


ALTER TABLE `kexon_personallocker`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

