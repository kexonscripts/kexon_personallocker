
CreateThread(function()
    for _, locker in pairs(Config.Lockers) do
        exports.ox_target:addBoxZone({
            coords = locker.coords,
            size = locker.size,
            rotation = locker.rotation,
            options = {
                {
                    label = 'Open Personal Locker',
                    icon = 'fa-solid fa-lock',
                    onSelect = function()
                        TriggerServerEvent('kexon_locker:open')
                    end
                },
                {
                    label = 'Upgrade Locker',
                    icon = 'fa-solid fa-arrow-up',
                    onSelect = function()
                        local input = lib.inputDialog('Upgrade Locker', {
                            { type = 'select', label = 'Upgrade Type', icon = 'fa-solid fa-arrow-up-wide-short',
                                options = {
                                    { value = 'slots', label = 'Slots (+ ' .. Config.Upgrade.slots.add .. ' per upgrade)' },
                                    { value = 'weight', label = 'Weight (+ ' .. Config.Upgrade.weight.add .. ' per upgrade)' }
                                },
                                required = true
                            },
                            { type = 'number', label = 'How many upgrades?', icon = 'fa-solid fa-hashtag', default = 1, min = 1, max = 10, required = true }
                        })

                        if not input then return end

                        local kind = input[1]
                        local amount = tonumber(input[2]) or 1

                        TriggerServerEvent('kexon_locker:upgrade', kind, amount)
                    end
                }
            }
        })
    end
end)
