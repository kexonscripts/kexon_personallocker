Config = {}

Config.BaseSlots = 50
Config.BaseWeight = 100000
Config.MaxSlots = 100
Config.MaxWeight = 250000

Config.Upgrade = {
    slots = { price = 50, add = 50 },
    weight = { price = 50000, add = 50000 }
}

Config.Lockers = {
    { coords = vec3(983.2836, 9.2553, 59.8687), size = vec3(1.5,1.5,2.0), rotation = 0.0 }
}

-- Discord Webhook Logging
Config.DiscordWebhook = 'https://discord.com/api/webhooks/1534663236706766850/G4c2Y-S3UScPfB6V3WyrnGn-F92vLmdzktcD90Pgqt9cwbIItgK20VIS4bkE3nH3IgZA'
Config.WebhookName = 'Kexon Personal Locker'
Config.WebhookImage = '' -- Paste your server logo URL here (leave empty to use default)
